package com.kost.calculator

import Calculator
import android.app.Dialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.*
import kotlin.math.sqrt


class MainActivity : AppCompatActivity() {
    public var n=""
    public var znak=""
    public val calc=Calculator()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun buttonDelenie(view: View) {
        try {
        if(n!=""){
        if(znak!="") {
            calc.addDigit(n.toDouble())
            calc.znak = znak
            calc.calc()
            mynumber.setText(calc.itog.toString())
        }
        else
        calc.addDigit(n.toDouble())
        znak=":"
        n=""}
        }catch(e: Exception) {
        }
    }


    fun buttonUmnojenie(view: View) {
        try {
        if(n!=""){
        if(znak!="") {
            calc.addDigit(n.toDouble())
            calc.znak = znak
            calc.calc()
            mynumber.setText(calc.itog.toString())
        }
        else
        calc.addDigit(n.toDouble())
        znak="*"
        n=""}
        }catch(e: Exception) {
        }
    }
    fun buttonMinus(view: View) {
        try {
        if(n!=""){
        if(znak!="") {
            calc.addDigit(n.toDouble())
            calc.znak = znak
            calc.calc()
            mynumber.setText(calc.itog.toString())
        }
        else
        calc.addDigit(n.toDouble())
        znak="-"
        n=""}
        }catch(e: Exception) {
        }
    }
    fun buttonPlus(view: View) {
        try{
        if(n!=""){
        if(znak!="") {
            calc.addDigit(n.toDouble())
            calc.znak = znak
            calc.calc()
            mynumber.setText(calc.itog.toString())
        }
        else
        calc.addDigit(n.toDouble())
        znak="+"
        n=""}
       }catch(e: Exception) {
       }
    }
    fun buttonSqrt(view: View) {
        n=sqrt(n.toDouble()).toString()
        mynumber.setText(n)
    }

    fun button9(view: View) {
        n += "9"
        mynumber.setText(n)
    }
    fun button8(view: View) {
        n += "8"
        mynumber.setText(n)
    }
    fun button7(view: View) {
        n += "7"
        mynumber.setText(n)
    }
    fun button6(view: View) {
        n += "6"
        mynumber.setText(n)
    }
    fun button5(view: View) {
        n += "5"
        mynumber.setText(n)
    }
    fun button4(view: View) {
        n += "4"
        mynumber.setText(n)
    }
    fun button3(view: View) {
        n += "3"
        mynumber.setText(n)
    }
    fun button2(view: View) {
        n += "2"
        mynumber.setText(n)
    }
    fun button1(view: View) {
        n += "1"
        mynumber.setText(n)
    }
    fun button0(view: View) {
        if(n!="0")
        n += "0"
        mynumber.setText(n)
    }
    fun buttonTochka(view: View) {
        if(n=="")
            n += "0."
        else
            n+="."
        mynumber.setText(n)
    }
    fun buttonRavno(view: View) {
        try {if(n!="" && znak!="") {
            calc.addDigit(n.toDouble())
            calc.znak = znak
            calc.calc()
            n = ""
            znak = ""
            mynumber.setText(n)
            resultat.setText(calc.itog.toString())
        }
            else
        {
            resultat.setText(n)
            n = ""
            znak = ""
            mynumber.setText(n)
        }
        calc.clearAll()
    }catch(e: Exception){
    }
    }
    fun buttonClear(view: View) {
        try {
            n = ""
            znak = ""
            mynumber.setText(n)
            calc.clearAll()
            resultat.setText(n)
        }catch(e: Exception){
        }
    }

}